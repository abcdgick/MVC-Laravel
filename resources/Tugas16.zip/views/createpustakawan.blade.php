@extends('master') 
@section('title', 'Tambah Pustakawan') 

@section('content')
<div class="container mb-3 mt-3">
    <h2>Tambah Data Pustakawan</h2>  
	@if(count($errors)>0)
		<div class="alert alert-danger">
			<ul class="mb-0">
				@foreach($errors->all() as $err)
					<li>{{$err}}</li>
				@endforeach
			</ul>
		</div>
	@endif
    <form method="post" action="/savepustakawan">
        @csrf
	    <div class="mb-3 mt-3">
		    <label for="nip" class="form-label">NIP :</label>
		    <input type="text" class="form-control" id="nip" name="nip">
	    </div>  
    	<div class="mb-3 mt-3">
		    <label for="nama" class="form-label">Nama :</label>
		    <input type="text" class="form-control" id="nama" name="nama">
	    </div>
 	    <div class="mb-3 mt-3">
		    <label for="gol" class="form-label">Golongan :</label>
		    <input type="text" class="form-control" id="gol" name="gol">
	    </div>  

        <div class="mb-3 mt-3">
	        <button class="btn btn-success mb-2" type="submit">Simpan</button>
            <button class="btn btn-warning mb-2" type="reset">Batal</button>
        </div>
    </form>
</div>
@endsection
